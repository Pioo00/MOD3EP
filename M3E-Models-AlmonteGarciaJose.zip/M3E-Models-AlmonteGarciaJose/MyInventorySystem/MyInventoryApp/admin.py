from django.contrib import admin
from .models import Supplier, WaterBottle

# Register your models here.
admin.site.register([Supplier, WaterBottle])