from django.apps import AppConfig

class MyinventoryappConfig(AppConfig):
    name = 'MyInventoryApp'
